/*
@header({
  searchable: 2,
  filterable: 0,
  quickSearch: 1,
  title: '索尼资源[资]',
  '类型': '影视',
  lang: 'ds'
})
*/

// https://suoniapi.com/api.php/provide/vod/?ac=list
// https://suoniapi.com/api.php/provide/vod/from/snm3u8/?ac=list

var rule = {
    模板: '采集1',
    title: '索尼资源[资]',
    host: 'https://suoniapi.com',
    // homeTid: '13',
    homeTid: '',
    cate_exclude: '电影|电视剧|综艺|动漫|电影解说|体育|演员|新闻资讯|诺克|女频',
    parse_url: '',
}